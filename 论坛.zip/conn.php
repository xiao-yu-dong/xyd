<?php
    $conn = mysqli_connect('localhost', 'root', 'root', 'xuesheng');
    mysqli_set_charset($conn, 'utf8');
